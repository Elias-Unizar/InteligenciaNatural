"""
Search (Chapters 3-4)

The way to use this code is to subclass Problem to create a class of problems,
then create problem instances and solve them with calls to the various search
functions.
"""

import sys
import time
from collections import deque

from utils import *


class Problem:
    """The abstract class for a formal problem. You should subclass
    this and implement the methods actions and result, and possibly
    __init__, goal_test, and path_cost. Then you will create instances
    of your subclass and solve them with the various search functions."""

    def __init__(self, initial, goal=None):
        """The constructor specifies the initial state, and possibly a goal
        state, if there is a unique goal. Your subclass's constructor can add
        other arguments."""
        self.initial = initial
        self.goal = goal

    def actions(self, state):
        """Return the actions that can be executed in the given
        state. The result would typically be a list, but if there are
        many actions, consider yielding them one at a time in an
        iterator, rather than building them all at once."""
        raise NotImplementedError

    def result(self, state, action):
        """Return the state that results from executing the given
        action in the given state. The action must be one of
        self.actions(state)."""
        raise NotImplementedError

    def goal_test(self, state):
        """Return True if the state is a goal. The default method compares the
        state to self.goal or checks for state in self.goal if it is a
        list, as specified in the constructor. Override this method if
        checking against a single self.goal is not enough."""
        if isinstance(self.goal, list):
            return is_in(state, self.goal)
        else:
            return state == self.goal

    def path_cost(self, c, state1, action, state2):
        """Return the cost of a solution path that arrives at state2 from
        state1 via action, assuming cost c to get up to state1. If the problem
        is such that the path doesn't matter, this function will only look at
        state2. If the path does matter, it will consider c and maybe state1
        and action. The default method costs 1 for every step in the path."""
        return c + 1

    def value(self, state):
        """For optimization problems, each state has a value. Hill Climbing
        and related algorithms try to maximize this value."""
        raise NotImplementedError


# ______________________________________________________________________________


class Node:
    """A node in a search tree. Contains a pointer to the parent (the node
    that this is a successor of) and to the actual state for this node. Note
    that if a state is arrived at by two paths, then there are two nodes with
    the same state. Also includes the action that got us to this state, and
    the total path_cost (also known as g) to reach the node. Other functions
    may add an f and h value; see best_first_graph_search and astar_search for
    an explanation of how the f and h values are handled. You will not need to
    subclass this class."""

    def __init__(self, state, parent=None, action=None, path_cost=0):
        """Create a search tree Node, derived from a parent by an action."""
        self.state = state
        self.parent = parent
        self.action = action
        self.path_cost = path_cost
        self.depth = 0
        if parent:
            self.depth = parent.depth + 1

    def __repr__(self):
        return "<Node {}>".format(self.state)

    def __lt__(self, node):
        return self.state < node.state

    def expand(self, problem):
        """List the nodes reachable in one step from this node."""
        return [self.child_node(problem, action)
                for action in problem.actions(self.state)]

    def child_node(self, problem, action):
        """[Figure 3.10]"""
        next_state = problem.result(self.state, action)
        next_node = Node(next_state, self, action, problem.path_cost(self.path_cost, self.state, action, next_state))
        return next_node

    def solution(self):
        """Return the sequence of actions to go from the root to this node."""
        return [node.action for node in self.path()[1:]]

    def path(self):
        """Return a list of nodes forming the path from the root to this node."""
        node, path_back = self, []
        while node:
            path_back.append(node)
            node = node.parent
        return list(reversed(path_back))

    def path_states(self):
        """Return the sequence of states on the path from the root to this node.

        The search functions return the goal ``Node`` (staying close to the book's
        pseudocode); this is the one-call way to read off the whole solution path as
        states -- ``solution()`` gives the corresponding actions.
        """
        return [node.state for node in self.path()]

    # We want for a queue of nodes in breadth_first_graph_search or
    # astar_search to have no duplicated states, so we treat nodes
    # with the same state as equal. [Problem: this may not be what you
    # want in other contexts.]

    def __eq__(self, other):
        return isinstance(other, Node) and self.state == other.state

    def __hash__(self):
        # We use the hash value of the state
        # stored in the node instead of the node
        # object itself to quickly search a node
        # with the same state in a Hash Table
        return hash(self.state)


# ______________________________________________________________________________


class SimpleProblemSolvingAgentProgram:
    """
    [Figure 3.1]
    Abstract framework for a problem-solving agent.
    """

    def __init__(self, initial_state=None):
        """State is an abstract representation of the state
        of the world, and seq is the list of actions required
        to get to a particular state from the initial state(root)."""
        self.state = initial_state
        self.seq = []

    def __call__(self, percept):
        """[Figure 3.1] Formulate a goal and problem, then
        search for a sequence of actions to solve it."""
        self.state = self.update_state(self.state, percept)
        if not self.seq:
            goal = self.formulate_goal(self.state)
            problem = self.formulate_problem(self.state, goal)
            self.seq = self.search(problem)
            if not self.seq:
                return None
        return self.seq.pop(0)

    def update_state(self, state, percept):
        """Update the agent's world state from the latest percept (abstract)."""
        raise NotImplementedError

    def formulate_goal(self, state):
        """Decide on a goal to pursue given the current state (abstract)."""
        raise NotImplementedError

    def formulate_problem(self, state, goal):
        """Build a Problem instance from the current state and chosen goal (abstract)."""
        raise NotImplementedError

    def search(self, problem):
        """Return a sequence of actions that solves the given problem (abstract)."""
        raise NotImplementedError


# ______________________________________________________________________________
# Uninformed Search algorithms


def breadth_first_tree_search(problem):
    """
    [Figure 3.7]
    Search the shallowest nodes in the search tree first.
    Search through the successors of a problem to find a goal.
    The argument frontier should be an empty queue.
    Repeats infinitely in case of loops.
    """
    iniTimer = time.time()
    maxQS = 0
    nodExpandidos = 0
    nodGenerados = 1
    frontier = deque([Node(problem.initial)])  # FIFO queue

    while frontier:
        node = frontier.popleft()
        if problem.goal_test(node.state):
            finTimer = time.time()
            return {"nodo":node, "profundidad":node.depth, "expandidos":nodExpandidos, 
                    "qSize":frontier.__len__(), "maxQS":maxQS, "tiempo":(finTimer-iniTimer), 
                    "generados":nodGenerados}
        nodGenerados = nodGenerados - frontier.__len__()
        frontier.extend(node.expand(problem))
        nodExpandidos += 1
        nodGenerados += frontier.__len__()
        if(maxQS < frontier.__len__()):
            maxQS = frontier.__len__()
    return None


def depth_first_tree_search(problem):
    """
    [Figure 3.7]
    Search the deepest nodes in the search tree first.
    Search through the successors of a problem to find a goal.
    The argument frontier should be an empty queue.
    Repeats infinitely in case of loops.
    """
    iniTimer = time.time()
    maxQS = 0
    nodExpandidos = 0
    nodGenerados = 1
    frontier = [Node(problem.initial)]  # Stack

    while frontier:
        node = frontier.pop()
        if problem.goal_test(node.state):
            finTimer = time.time()
            return {"nodo":node, "profundidad":node.depth, "expandidos":nodExpandidos, 
                                "qSize":frontier.__len__(), "maxQS":maxQS, "tiempo":(finTimer-iniTimer), 
                                "generados":nodGenerados}
        nodGenerados -= frontier.__len__()
        frontier.extend(node.expand(problem))
        nodGenerados += frontier.__len__()
        nodExpandidos += 1
        if(maxQS < frontier.__len__()):
            maxQS = frontier.__len__()
    return None


def depth_first_graph_search(problem):
    """
    [Figure 3.7]
    Search the deepest nodes in the search tree first.
    Search through the successors of a problem to find a goal.
    The argument frontier should be an empty queue.
    Does not get trapped by loops.
    If two paths reach a state, only use the first one.
    """
    iniTimer = time.time()
    maxQS = 0
    nodExpandidos = 0
    nodGenerados = 1
    frontier = [(Node(problem.initial))]  # Stack

    explored = set()
    while frontier:
        node = frontier.pop()
        if problem.goal_test(node.state):
            finTimer = time.time()
            return {"nodo":node, "profundidad":node.depth, "expandidos":nodExpandidos, 
                                "qSize":frontier.__len__(), "maxQS":maxQS, "tiempo":(finTimer-iniTimer), 
                                "generados":nodGenerados}
        explored.add(node.state)
        nodGenerados -= frontier.__len__()
        frontier.extend(child for child in node.expand(problem)
                        if child.state not in explored and child not in frontier)
        nodGenerados += frontier.__len__()
        nodExpandidos += 1
        if(maxQS < frontier.__len__()):
            maxQS = frontier.__len__()
    return None


def breadth_first_graph_search(problem):
    """[Figure 3.11]
    Note that this function can be implemented in a
    single line as below:
    return graph_search(problem, FIFOQueue())
    """
    iniTimer = time.time()
    maxQS = 0
    nodExpandidos = 0
    nodGenerados = 1

    node = Node(problem.initial)
    if problem.goal_test(node.state):
        finTimer = time.time()
        return {"nodo":node, "profundidad":node.depth, "expandidos":nodExpandidos, 
                            "qSize":0, "maxQS":maxQS, "tiempo":(finTimer-iniTimer), 
                            "generados":nodGenerados}
    frontier = deque([node])
    explored = set()
    while frontier:
        node = frontier.popleft()
        explored.add(node.state)
        for child in node.expand(problem):
            if child.state not in explored and child not in frontier:
                nodGenerados += 1
                if problem.goal_test(child.state):
                    if(maxQS < frontier.__len__()):
                        maxQS = frontier.__len__()
                    finTimer = time.time()
                    return {"nodo":child, "profundidad":child.depth, "expandidos":nodExpandidos, 
                                                "qSize":frontier.__len__(), "maxQS":maxQS, "tiempo":(finTimer-iniTimer), 
                                                "generados":nodGenerados}
                frontier.append(child)
        nodExpandidos += 1
        if(maxQS < frontier.__len__()):
            maxQS = frontier.__len__()
    return None


def best_first_graph_search(problem, f, display=False):
    """Search the nodes with the lowest f scores first.
    You specify the function f(node) that you want to minimize; for example,
    if f is a heuristic estimate to the goal, then we have greedy best
    first search; if f is node.depth then we have breadth-first search.
    There is a subtlety: the line "f = memoize(f, 'f')" means that the f
    values will be cached on the nodes as they are computed. So after doing
    a best first search you can examine the f values of the path returned."""
    iniTimer = time.time()
    maxQS = 0
    nodExpandidos = 0
    nodGenerados = 1
    
    f = memoize(f, 'f')
    node = Node(problem.initial)
    frontier = PriorityQueue('min', f)
    frontier.append(node)
    explored = set()
    while frontier:
        node = frontier.pop()
        if problem.goal_test(node.state):
            if display:
                print(len(explored), "paths have been expanded and", len(frontier), "paths remain in the frontier")
            finTimer = time.time()
            return {"nodo":node, "profundidad":node.depth, "expandidos":nodExpandidos, 
                    "qSize":frontier.__len__(), "maxQS":maxQS, "tiempo":(finTimer-iniTimer), 
                    "generados":nodGenerados}
        explored.add(node.state)
        for child in node.expand(problem):
            if child.state not in explored and child not in frontier:
                nodGenerados += 1
                frontier.append(child)
            elif child in frontier:
                if f(child) < frontier[child]:
                    del frontier[child]
                    frontier.append(child)
        nodExpandidos += 1
        if(maxQS < frontier.__len__()):
            maxQS = frontier.__len__()
    return None

def uniform_cost_search(problem, display=False):
    """[Figure 3.14]"""
    return best_first_graph_search(problem, lambda node: node.path_cost, display)

def depth_limited_search(problem, limit=50):
    """[Figure 3.17]"""

    def recursive_dls(node, problem, limit, nodExpandidos, nodGenerados):
        if problem.goal_test(node.state):
            return node, nodExpandidos, nodGenerados
        elif limit == 0:
            return 'cutoff', nodExpandidos, nodGenerados
        else:
            cutoff_occurred = False
            nodExpandidos += 1
            nodGenerados += (node.expand(problem)).__len__()
            for child in node.expand(problem):
                result, nodExpandidos, nodGenerados = recursive_dls(child, problem, limit - 1, nodExpandidos, nodGenerados)
                if result == 'cutoff':
                    cutoff_occurred = True
                elif result is not None:
                    return result, nodExpandidos, nodGenerados
            if cutoff_occurred: 
                return 'cutoff', nodExpandidos, nodGenerados 
            else:
                None, nodExpandidos, nodGenerados

    # Body of depth_limited_search:
    iniTimer = time.time()
    result, nodExpand, nodGen = recursive_dls(Node(problem.initial), problem, limit, 0, 1)
    finTimer = time.time()
    if result == 'cutoff':
        return {"nodo":result, "profundidad":"LIMITE ALCANZADO", "expandidos":"LIMITE ALCANZADO", 
                "qSize":"LIMITE ALCANZADO", "maxQS":"LIMITE ALCANZADO", "tiempo":(finTimer-iniTimer), 
                "generados":"LIMITE ALCANZADO"}   
    elif result is not None:
        return {"nodo":result, "profundidad":result.depth, "expandidos":nodExpand, 
                "qSize":0, "maxQS":0, "tiempo":(finTimer-iniTimer), 
                "generados":nodGen}        
    else:
        return None

def iterative_deepening_search(problem):
    """[Figure 3.18]"""
    iniTimer = time.time()
    for depth in range(35):
        resultDict = depth_limited_search(problem, depth)
        if resultDict["nodo"] != 'cutoff':
            finTimer = time.time()
            if resultDict is not None:
                resultDict["tiempo"] = finTimer - iniTimer
                return resultDict   
 


greedy_best_first_graph_search = best_first_graph_search


# Greedy best-first search is accomplished by specifying f(n) = h(n).


def astar_search(problem, h=None, display=False):
    """A* search is best-first graph search with f(n) = g(n)+h(n).
    You need to specify the h function when you call astar_search, or
    else in your Problem subclass."""
    h = memoize(h or problem.h, 'h')
    return best_first_graph_search(problem, lambda n: n.path_cost + h(n), display)


def iterative_deepening_astar_search(problem, h=None):
    """[Section 3.5.3] Iterative-deepening A* search: repeatedly run a depth-first
    search bounded by an f = g + h contour, raising the bound to the smallest f
    that exceeded it, until a goal within the bound is found."""
    h = memoize(h or problem.h, 'h')

    def f(node):
        return node.path_cost + h(node)

    def contour(node, bound):
        """Depth-first search pruned at f(node) > bound. Return a goal Node, or
        the smallest f-value among the nodes that exceeded the bound."""
        if f(node) > bound:
            return f(node)
        if problem.goal_test(node.state):
            return node
        minimum = np.inf
        for child in node.expand(problem):
            # avoid cycles along the current path
            if child.state not in (ancestor.state for ancestor in node.path()):
                result = contour(child, bound)
                if isinstance(result, Node):
                    return result
                minimum = min(minimum, result)
        return minimum

    node = Node(problem.initial)
    bound = f(node)
    while True:
        result = contour(node, bound)
        if isinstance(result, Node):
            return result
        if result == np.inf:
            return None
        bound = result


# ______________________________________________________________________________
# A* heuristics

class EightPuzzle(Problem):
    """ The problem of sliding tiles numbered from 1 to 8 on a 3x3 board, where one of the
    squares is a blank. A state is represented as a tuple of length 9, where  element at
    index i represents the tile number  at index i (0 if it's an empty square) """

    def __init__(self, initial, goal=(0, 1, 2, 3, 4, 5, 6, 7, 8)):
        """ Define goal state and initialize a problem """
        super().__init__(initial, goal)

    def find_blank_square(self, state):
        """Return the index of the blank square in a given state"""

        return state.index(0)

    def actions(self, state):
        """ Return the actions that can be executed in the given state.
        The result would be a list, since there are only four possible actions
        in any given state of the environment """

        possible_actions = ['UP', 'DOWN', 'LEFT', 'RIGHT']
        index_blank_square = self.find_blank_square(state)

        if index_blank_square % 3 == 0:
            possible_actions.remove('LEFT')
        if index_blank_square < 3:
            possible_actions.remove('UP')
        if index_blank_square % 3 == 2:
            possible_actions.remove('RIGHT')
        if index_blank_square > 5:
            possible_actions.remove('DOWN')

        return possible_actions

    def result(self, state, action):
        """ Given state and action, return a new state that is the result of the action.
        Action is assumed to be a valid action in the state """

        # blank is the index of the blank square
        blank = self.find_blank_square(state)
        new_state = list(state)

        delta = {'UP': -3, 'DOWN': 3, 'LEFT': -1, 'RIGHT': 1}
        neighbor = blank + delta[action]
        new_state[blank], new_state[neighbor] = new_state[neighbor], new_state[blank]

        return tuple(new_state)

    def goal_test(self, state):
        """ Given a state, return True if state is a goal state or False, otherwise """

        return state == self.goal

    def check_solvability(self, state):
        """ Checks if the given state is solvable """

        inversion = 0
        for i in range(len(state)):
            for j in range(i + 1, len(state)):
                if (state[i] > state[j]) and state[i] != 0 and state[j] != 0:
                    inversion += 1

        return inversion % 2 == 0

    def h(self, node):
        """ Return the heuristic value for a given state. Default heuristic function used is
        h(n) = number of misplaced tiles """

        return sum(s != g for (s, g) in zip(node.state, self.goal))
    
    def h_mahattan(self, node):
        costeCaminar = 0
        objetivo = self.goal
        posFichai = 0
        for i in node.state:
            if i == 0: 
                posFichai += 1
                continue
            posFinalElementoi = objetivo.index(i)
           #Con aux/3 calculamos el numero de filas que estamos
           #Con aux%3 calculamos el numero de columnas que estamos
            costeCaminar += abs(posFichai // 3 - posFinalElementoi // 3) + abs(posFichai % 3 - posFinalElementoi % 3)#Calculamos el numero total de pasos para una cierta pieza
            posFichai += 1
        return costeCaminar